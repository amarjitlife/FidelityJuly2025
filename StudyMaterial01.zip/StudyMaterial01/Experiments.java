
package learnJava;

//_________________________________________________________________

class Spiderman {
	public void fly() { System.out.println("Fly Like Spiderman!"); }
	public void saveWorld() { System.out.println("Save World Like Spiderman!"); }
}

class Superman {
	public void fly() { System.out.println("Fly Like Superman!"); }
	public void saveWorld() { System.out.println("Save World Like Superman!"); }
}

class Wonderwoman {
	public void fly() { System.out.println("Fly Like Wonderwoman!"); }
	public void saveWorld() { System.out.println("Save World Like Wonderwoman!"); }
}

//_________________________________________________________________

// class Human {

// Using Mechanism Inheritance
//		Code Reduce
// class Human extends Spiderman {
// class Human extends Superman {
class Human extends Wonderwoman {
	public void fly() 		{ super.fly(); } 	//{ System.out.println("Fly Like Human!"); }
	public void saveWorld() { super.saveWorld(); } //{ System.out.println("Save World Like Human!"); }
}

//_________________________________________________________________

// Using Mechanims Composition
//		Code Reuse

// Composition Is Equivalent To Inheritance

// DESIGN PRACTICE
//		ALWAYS PREFER COMPOSITION OVER INHERITANCE
class HumanBetter {
	// Spiderman power = new Spiderman();
	// Superman power = new Superman();
	Wonderwoman power = new Wonderwoman();

	public void fly() 		{ power.fly(); } 	//{ System.out.println("Fly Like Human!"); }
	public void saveWorld() { power.saveWorld(); } //{ System.out.println("Save World Like Human!"); }
}

//_________________________________________________________________
//_________________________________________________________________
//_________________________________________________________________
//_________________________________________________________________

public class Experiments {
	
	public static void playWithHuman() {
		System.out.println("\nSpiderman");
		Spiderman s = new Spiderman();
		s.fly();
		s.saveWorld();

		System.out.println("\nHuman");
		Human h = new Human();
		h.fly();
		h.saveWorld();
	}

	public static void playWithHumanBetter() {
		System.out.println("\nSpiderman");
		Spiderman s = new Spiderman();
		s.fly();
		s.saveWorld();

		System.out.println("\nHumanBetter");
		HumanBetter hb = new HumanBetter();
		hb.fly();
		hb.saveWorld();
	}

	public static void main( String[] args ) {
		System.out.println("\n\nFunction : playWithHuman");
		playWithHuman();

		System.out.println("\n\nFunction : playWithHumanBetter");
		playWithHumanBetter();

		// System.out.println("\n\nFunction : ");
		// System.out.println("\n\nFunction : ");
		// System.out.println("\n\nFunction : ");
		// System.out.println("\n\nFunction : ");
		// System.out.println("\n\nFunction : ");
	}
}


//_________________________________________________________________
//_________________________________________________________________
//_________________________________________________________________
//_________________________________________________________________
//_________________________________________________________________


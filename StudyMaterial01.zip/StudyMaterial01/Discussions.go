12:32:11 From Amarjit Singh To Everyone:
	What Is Object Oriented Programming?

12:32:40 From Venkat Mohanram (He / Him) To Everyone:
	organizing objects

12:33:16 From saquib To Everyone:
	It organizes objects rather than functions

12:33:22 From Arkadip Basu To Everyone:
	extendeding features

12:33:32 From Satyam Verma To Everyone:
	Make code resueable, we can create instance of our class,
	 and have access to Polymorphism, Inheritance

12:33:35 From R Boobalan To Amarjit Singh(direct message):
	OOPS has some concepts like class and object and inheritance , encpacsulation and some other.	
	Helps to magenage the code and handle its without complexity.

12:33:54 From Harish M.L To Everyone:
	way of organizing the objects in a software package

12:33:56 From Siva Ramakrishna Challa To Everyone:
	Organizes code into objects

12:33:57 From Swetha Venkataswamy To Everyone:
	programming language based on objects

12:34:15 From Nagaraj M To Everyone:
	An approach of modelling the problem space, in terms of objects and state

12:34:37 From Ponmaniraja Vellaiyan To Everyone:
	organizes software design around objects

12:35:05 From Suresh R To Amarjit Singh(direct message):
	organizing objects

12:35:07 From Naveen Lakshmanan To Everyone:
	Programming by creating objects as instances of classes

12:35:11 From Ram To Everyone:
	Object-oriented programming language is based on concept of "Objects"

12:35:20 From Sathish Kumar C To Everyone:
	bundled together as objects

12:35:22 From Jyothi Rajesh To Everyone:
	more modular

12:35:32 From Harsh Vardhan Singh To Everyone:
	based on coupling of objects

12:35:36 From Raghav Jagan To Everyone:
	advance options

	
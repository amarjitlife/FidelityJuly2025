
#include <stdio.h>

//_________________________________________________________________

// Object Oriented Programming
//	1. Abstraction
// 	2. Encapsulation
//	3. Inheritance
//	4. Polymorphism

typedef struct human_struct {
	int id;
	char name[100];
	void (*dance)();
} Human;

void doBhangra() { printf("\n\tDancing: Doing Bhangra..."); }
void doHipHop()  { printf("\n\tDancing: Doing Hip Hop..."); }

//_________________________________________________________________

// In C++/Java
// class Human {
// 		int id;
// 		char name[100];
// 		// void (*dance)();
// 		void doBhangra() { printf("\n\tDancing: Doing Bhangra..."); }
// 		void doHipHop()  { printf("\n\tDancing: Doing Hip Hop..."); }
// } 

//_________________________________________________________________


void playWithHuman() {
	// gabbar Is Object?
						// Constructor Call
	Human gabbar = { 420, "Gabbar Singh", doBhangra };

	printf("\nID 	: %d", gabbar.id );
	printf("\nName	: %s", gabbar.name );
	gabbar.dance(); // dance Is Polymorphic

	Human basanti = { 100, "Basanti Dancer", doHipHop };

	printf("\nID 	: %d", basanti.id );
	printf("\nName	: %s", basanti.name );
	basanti.dance();
}

// Function: playWithHuman
// ID 	: 420
// Name	: Gabbar Singh
// 	Dancing: Doing Bhangra...

// ID 	: 100
// Name	: Basanti Dancer
// 	Dancing: Doing Hip Hop...

//_________________________________________________________________
//_________________________________________________________________
//_________________________________________________________________
//_________________________________________________________________
//_________________________________________________________________

void main() {
	printf("\n\nFunction: playWithHuman");
	playWithHuman();

	// printf("\n\nFunction: ");
	// printf("\n\nFunction: ");
	// printf("\n\nFunction: ");
	// printf("\n\nFunction: ");
	// printf("\n\nFunction: ");
	// printf("\n\nFunction: ");
	// printf("\n\nFunction: ");
	// printf("\n\nFunction: ");
	// printf("\n\nFunction: ");
}

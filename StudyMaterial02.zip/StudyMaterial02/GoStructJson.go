

package main

import (
	"fmt"
	"encoding/json"
	"log"
)

//___________________________________________________________________

type Movie struct {
	Title string
	Year int  		 `json:"Released Year"`
	Color bool 		 `json:"Movie Color"`
	Actors []string  `json:"omitempty"`
}

var movies = []Movie{
	{ Title : "Shole", Year: 1990, Color : true, Actors: []string { "Dharamender", "Amitabh", "Hemamalini", "Sanjeev Kumar", "Gabbar Singh"}},
	{ Title : "Bajrangi Bhaijan", Year: 2010, Color : true, Actors: []string { "Salman", "Nawajudin Sidqui", "Little Girl"} },
	{ Title : "Muggle Azam", Year: 1960, Color : false, Actors: []string { "Dilip", "Madhubala", "Pritvi Raj Kappor" }},
	{ Title : "DDLJ", Year: 2010, Color : true, Actors: []string { "Kajol", "Shahrukh", "Amrish Puri"}},
	{ Title : "Ding DOng", Color : false, Year: 2010, Actors: []string{} },
}

func playWithMoviesMarshallingAndUnMarshalling() {

	for index, movie := range movies {
		fmt.Println(index, movie)
	}

	{   // Marshalling Means Converting Collection Data Into JSON Format Data
		jsonData, err := json.Marshal( movies )
		if err != nil {
			log.Fatalf("JSON Marshalling Failed! %s", err)
		}
		fmt.Printf(" %s \n ", jsonData )
	}


	jsonData, err := json.MarshalIndent( movies, "", "	" )
	if err != nil {
		log.Fatalf("JSON Marshalling Failed! %s", err)
	}
	fmt.Printf(" %s \n ", jsonData )

	/*
		type MovieTitle struct { 
			Title string 
		}

		var moviesTitles []MovieTitle
	*/

	// Following Line Of Code Is Equivalent To Above Code
	// Unnamed Structure Type
	//		Creating Object As Well As Type Of Object In Single Line
	var moviesTitle []struct { Title string }

	if err := json.Unmarshal( jsonData, &moviesTitle ) ; err != nil {
			log.Fatalf("JSON UNMarshalling Failed! %s", err)
	}
	fmt.Printf("Movies Title:  %s \n ", moviesTitle )

	var moviesData []Movie
	if err := json.Unmarshal( jsonData, &moviesData ) ; err != nil {
			log.Fatalf("JSON UNMarshalling Failed! %s", err)
	}
	fmt.Println("Movies: ", moviesData )
}


//___________________________________________________________________
//___________________________________________________________________
//___________________________________________________________________
//___________________________________________________________________
//___________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

func main() {
	fmt.Println("\nFunction : playWithMoviesMarshallingAndUnMarshalling")	
	playWithMoviesMarshallingAndUnMarshalling()

	// fmt.Println("\nFunction : ")	
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")	
	// fmt.Println("\nFunction : ")	
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")	
}



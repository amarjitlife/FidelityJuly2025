
__________________________________________________________________________

DAY 01
__________________________________________________________________________

Assignments A0: Revise and Practice Go Fundamentals

Assignments A1: Revise and Practice Go Code Done In The Class
		Extend Code Examples With Your Own Examples

Assignments A2: Reading Documentation and Practice Go Code	
	Reference Link: strings Pacakge 
			https://pkg.go.dev/strings
			https://go.dev/blog/strings

	Reference Link: Read Flag Documentation
			https://pkg.go.dev/fmt
			https://pkg.go.dev/io

Assignments A3: Reading Pointers and Array [ MUST MUST MUST ]
	Chapter 05: Pointers and Array
		Reference: 
		The C Programming Language, 2nd Editon, By Kernigham and Dennis Ritiche

__________________________________________________________________________

DAY 02
__________________________________________________________________________


Assignments A0: Revise and Practice Go Fundamentals

Assignments A1: Revise and Practice Go Code Done In The Class
		Extend Code Examples With Your Own Examples

Assignments A2: Reading Pointers and Array [ MUST MUST MUST ]
	Chapter 05: Pointers and Array
		Reference: 
		The C Programming Language, 2nd Editon, By Kernigham and Dennis Ritiche


__________________________________________________________________________

DAY 03
__________________________________________________________________________




__________________________________________________________________________
__________________________________________________________________________

12:32:11 From Amarjit Singh To Everyone:
	What Is Object Oriented Programming?

12:32:40 From Venkat Mohanram (He / Him) To Everyone:
	organizing objects

12:33:16 From saquib To Everyone:
	It organizes objects rather than functions

12:33:22 From Arkadip Basu To Everyone:
	extendeding features

12:33:32 From Satyam Verma To Everyone:
	Make code resueable, we can create instance of our class,
	 and have access to Polymorphism, Inheritance

12:33:35 From R Boobalan To Amarjit Singh(direct message):
	OOPS has some concepts like class and object and inheritance , encpacsulation and some other.	
	Helps to magenage the code and handle its without complexity.

12:33:54 From Harish M.L To Everyone:
	way of organizing the objects in a software package

12:33:56 From Siva Ramakrishna Challa To Everyone:
	Organizes code into objects

12:33:57 From Swetha Venkataswamy To Everyone:
	programming language based on objects

12:34:15 From Nagaraj M To Everyone:
	An approach of modelling the problem space, in terms of objects and state

12:34:37 From Ponmaniraja Vellaiyan To Everyone:
	organizes software design around objects

12:35:05 From Suresh R To Amarjit Singh(direct message):
	organizing objects

12:35:07 From Naveen Lakshmanan To Everyone:
	Programming by creating objects as instances of classes

12:35:11 From Ram To Everyone:
	Object-oriented programming language is based on concept of "Objects"

12:35:20 From Sathish Kumar C To Everyone:
	bundled together as objects

12:35:22 From Jyothi Rajesh To Everyone:
	more modular

12:35:32 From Harsh Vardhan Singh To Everyone:
	based on coupling of objects

12:35:36 From Raghav Jagan To Everyone:
	advance options

	
//__________________________________________________________________________________

09:25:25 From LnDCloud DelOps To Everyone:
	brb
09:41:55 From Naveen Lakshmanan To Everyone:
	package main
	import "fmt"
	
	type Circle struct {
	  radius float64
	  area float64
	}
	
	func (c Circle) calcArea(){
	  c.area = 3.14 * c.radius * c.radius
	}
	
	func main() {
	  c := Circle{ radius: 5 }
	  c.calcArea()
	  fmt.Printf("%+v\n", c)
	}
09:42:56 From Naveen Lakshmanan To Everyone:
	https://codeshare.io/ayD0n0
10:43:54 From Amarjit Singh To Everyone:
	https://codeshare.io/aYAErE
10:43:54 From Amarjit Singh To Everyone:
	https://codeshare.io/aYAErE
10:57:35 From Amarjit Singh To Everyone:
	Tea Break Till 11:15
11:10:48 From Amarjit Singh To Everyone:
	MOMENT YOU ARE BACK! Please RAISE YOUR HAND!
11:15:22 From Amarjit Singh To Everyone:
	What is Conncurrency?
	What is Parallelism?

11:15:58 From Amarjit Singh To Everyone:
	After Submitting your ANSWER for about questions please raise your hand

11:16:19 From Arkadip Basu To Everyone:
	Concurrency- managing multiple tasks that might be interleaved or executed in overlapping time period
	
	Parallelism- is about executing multiple tasks simultaneously

11:16:19 From Venkat Mohanram (He / Him) To Everyone:
	Concurrency - multiple tasks in progress at the same time
	Parallelism - simultaneous execution

11:17:02 From Harish M.L To Everyone:
	concurrency: E

11:17:10 From R Boobalan To Everyone:
	concurrency - A person prepare pasta , chop vegetables.
	parallelism is - each person complete a work together.

11:17:31 From Satyam Verma To Everyone:
	Concurrency- We are creating multiple go routines which are managed by go runtime

11:17:57 From Raghav Jagan To Everyone:
	Concurrency is execute all at a time, 
	parallelism is process all at a time

11:18:04 From Sathish Kumar C To Everyone:
	Parallelism - Execution of multiple tasks in sequence
	Concurrency - Many work at same time

11:18:24 From Satyam Verma To Everyone:
	Parallelism - At the same time multiple execution.

11:18:39 From Pawan Kumar Sinha To Everyone:
	Concurrency is working on multiple things at once.
	Parallelism is doing multiple things at same time.

11:18:51 From Suresh R To Everyone:
	concurrency - multiple tasks run sequentially while running
	parallelism - all tasks runs simultaneously/parallel execution

11:18:58 From Harish M.L To Everyone:
	Concurrency: Multiple tasks being handled
	parallelism: Same time execution of multiple task

11:19:14 From Santhosh To Everyone:
	concurrency: sequential execution of tasks
	parallelism: simultaneous execution

11:19:31 From saquib To Everyone:
	Concurrency - Execution of task in controlled way
	Parallelism - Run tasks in parallel

11:19:46 From Siva Ramakrishna Challa To Everyone:
	Concurrency: multiple tasks are in progress at same time but not executed at same time
	parallelism: multiple tasks are executed at same time

11:20:01 From Yogesh Pandian R To Everyone:
	Concurrency, running multiple tasks / progress with in the 
	same time period but not similataneously
	
	Parallelism, running multiple tasks at the same time as well but in parallel.
11:20:02 From Ram To Everyone:
	Concurrency: will perform couple of tasks at one time, but not simultenously

11:20:23 From Naveen Lakshmanan To Everyone:
	Concurrency: Execution of different task at the same time
	Parallesslis: Execution of same task parallelly

11:20:25 From Nagaraj M To Everyone:
	Concurrecy - Multiple active at same time; Parallelism - Multiple happening at same time


//__________________________________________________________________________________
//__________________________________________________________________________________
//__________________________________________________________________________________
//__________________________________________________________________________________
//__________________________________________________________________________________
//__________________________________________________________________________________
//__________________________________________________________________________________




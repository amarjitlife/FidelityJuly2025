
__________________________________________________________________________

DAY 01
__________________________________________________________________________

Assignments A0: Revise and Practice Go Fundamentals

Assignments A1: Revise and Practice Go Code Done In The Class
		Extend Code Examples With Your Own Examples

Assignments A2: Reading Documentation and Practice Go Code	
	Reference Link: strings Pacakge 
			https://pkg.go.dev/strings
			https://go.dev/blog/strings

	Reference Link: Read Flag Documentation
			https://pkg.go.dev/fmt
			https://pkg.go.dev/io

Assignments A3: Reading Pointers and Array [ MUST MUST MUST ]
	Chapter 05: Pointers and Array
		Reference: 
		The C Programming Language, 2nd Editon, By Kernigham and Dennis Ritiche

__________________________________________________________________________

DAY 02
__________________________________________________________________________


Assignments A0: Revise and Practice Go Fundamentals

Assignments A1: Revise and Practice Go Code Done In The Class
		Extend Code Examples With Your Own Examples

Assignments A2: Reading Pointers and Array [ MUST MUST MUST ]
	Chapter 05: Pointers and Array
		Reference: 
		The C Programming Language, 2nd Editon, By Kernigham and Dennis Ritiche

__________________________________________________________________________

DAY 03
__________________________________________________________________________

Assignments A1: Revise and Practice Go Code Done In The Class
		Extend Code Examples With Your Own Examples

Assignments A2: Reading and Coding Assignments
	
	Beginners Level Tutorials
		https://www.digitalocean.com/community/tutorials/how-to-make-an-http-server-in-go
		https://go.dev/doc/articles/wiki/	
		https://pkg.go.dev/os
		https://pkg.go.dev/bufio
		https://pkg.go.dev/io
		https://pkg.go.dev/net/http
		https://pkg.go.dev/net/
		https://pkg.go.dev/database/sql
		https://echo.labstack.com/docs
		https://gorm.io/index.html

Assignments A3: Reading Fundamentals
	
	Pointers and Array [ MUST MUST MUST ]
		Chapter 05: Pointers and Array
		Reference: 
		The C Programming Language, 2nd Editon, By Kernigham and Dennis Ritiche
	
	Processes and Thread [ MUST MUST MUST ]
		Syncronisation
			Mutex, Semphores, Pipes, Sockets, Files...
			Critical Section
		Reference: Operating System Design and Implementation, William Stalling

Assignments A4: Write Project Using Echo Framework
	Reference: Shared Sample Project
		ProjectRunnersMysql

__________________________________________________________________________
__________________________________________________________________________
__________________________________________________________________________
__________________________________________________________________________


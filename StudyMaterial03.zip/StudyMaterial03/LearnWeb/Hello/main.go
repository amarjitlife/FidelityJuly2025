
package main

import "fmt"
import "rsc.io/quote"

func main() {
	fmt.Println("Hello World!!!")
	fmt.Println( quote.Go() )
}

/*
mkdir Hello
cd Hello/
go mod init example.com/hello
ls
Created main.go
Write Above Code
go run main.go
go get rsc.io/quote
ls
cat go.mod
cat go.sum

go run main.go
go run .
*/


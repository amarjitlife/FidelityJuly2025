
package main

import (
	"fmt"
	"rsc.io/quote"
	"net/http"
	"log"
)

func hello( w http.ResponseWriter, req *http.Request ) {
	fmt.Println("Accessed: Hello Page!")
	fmt.Fprintf( w, "Hello Gabbar Singh!!! Welcome To Go Web!!!")
}

func home( w http.ResponseWriter, req *http.Request ) {
	fmt.Println("Accessed: Home Page!")
	w.Write( []byte("Welcome To Home Page!...") )
}

func main() {
	var serverAddress = ":8080"
	fmt.Println("Welcome To Go Web!")
	fmt.Println( quote.Go() )

	http.HandleFunc( "/hello", hello )
	http.HandleFunc( "/", home )
	// http.HandleFunc( "/snippet/view",  )
	// http.HandleFunc( "/snippet/create",  )

	err := http.ListenAndServe( serverAddress , nil )
	if err != nil {
		log.Fatal( err )
	}

	fmt.Println("Http Server Started: ", serverAddress )
}



package main

import (
	"fmt"
	"io/ioutil"
	"net/http"
	"os"
)

func main() {
	for _, url := range os.Args[1:] {
		response, err := http.Get( url )

		if err != nil {
			fmt.Fprintf( os.Stderr, "Fetch: %v\n", err )
			os.Exit( 1 )
		}

		body, err := ioutil.ReadAll( response.Body )
		defer response.Body.Close()

		if err != nil {
			fmt.Fprintf( os.Stderr, "Fetch Reading: %s: %v\n", url, err )
			os.Exit( 1 )	
		}

		// fmt.Printf("Received: %s", body)
		fmt.Printf("%s", body)
	}
}

/*
	go run . https://dummyjson.com/test https://dummyjson.com/ip | jq
*/


package main

import (
	"fmt"
	"math"
	"image/color"
	"bytes"
)

//_________________________________________________________________

// Go Lang: Modern C
//		Type Safe Language
//			Strictly Typed Languages
//		It's Expressive In Nature
//				Code Like Python and Think Like C
//		Concurrency Is Build Into It!
//		It' Garbage Collected Language
//		Design Towards Performance
//		Minimal Design

//_________________________________________________________________


// Structure Is Associative Type
//		Associates Multiple Type Of Data

//???
type Person struct {
	name string
	age int
}

// In C
// struct Person {
// 		name string
// 		age int
// }

func newPerson( name string ) *Person {
	p := Person{ name: name }
	p.age = 40
	return &p
}

//_________________________________________________________________

func playWithPerson() {
	p0 := Person{ "Gabbar Singh", 25 }

	fmt.Println( "Person: ", p0 )
	// fmt.Println( "Person: %v", p )

	p1 := Person{ name: "Gabbar Singh", age: 20 }
	fmt.Println("Person: ", p1 )

	fmt.Println( p1.name, p1.age )

	p2 := newPerson( "Alice Carol" )
	fmt.Println("Person: ", p2 )

	gabbar := Person{ name: "Gabbar Singh", age: 30 }
	address := &gabbar

	fmt.Println("Person: ", gabbar )
	fmt.Println("Person: ", address ) // *address

	fmt.Println("Person Name: ", gabbar.name )

	fmt.Println("Person Name: ", address.name  ) // (*address).name
	//Compiler Will Generate Following Like Of Code For Above Line
	fmt.Println("Person Name: ", (*address).name  )


			// Anonmous Structures
	dog := struct { // Defining Structure
		name string
		isGood bool
	} { // Creating Instance Of Structure
		"Someone",
		 true,
	}

	fmt.Println( dog )
}

// Function: playWithPerson
// Person:  {Gabbar Singh 25}
// Person:  {Gabbar Singh 20}
// Gabbar Singh 20
// Person:  &{Alice Carol 40}
// Person:  {Gabbar Singh 30}
// Person:  &{Gabbar Singh 30}
// Person Name:  Gabbar Singh
// Person Name:  Gabbar Singh

//_________________________________________________________________

type Celsius 	float64
type Fahrenheit float64

const (
	AbsoluteZeroC 	Celsius = -273.15
	FreezingC 		Celsius = 0
	BoilingC 		Celsius = 100
)

func playWithTypes() {
	var c Celsius 		= 90.2
	var f Fahrenheit 	= 100.2

	// result := c + f
	// ./GoStructures.go:106:12: 
	// 	invalid operation: c + f (mismatched types Celsius and Fahrenheit)

	result := c + Celsius( f )
	fmt.Println("Result: ", result )

	var ff float64
	var ii int = 90
	// ff = ii
	ff = float64( ii )
	fmt.Println("ff: ", ff ) 
	// cannot use ii (variable of type int) as float64 value in assignment
}

//_________________________________________________________________

type Circle struct {
	X, Y, Radius int
}

type Wheel struct {
	X, Y, Radius, Spokes int 
}

func playWithCirlcesAnWheel0() {
	var c Circle
	c.X = 10
	c.Y = 20
	c.Radius = 50
	fmt.Println("Cicle: ", c)

	var w Wheel
	w.X = 10
	w.Y = 20
	w.Radius = 50
	w.Spokes = 24
	fmt.Println("Wheel: ", w)
}

//_________________________________________________________________

type Point1 struct {
	X int
	Y int
}

type Circle1 struct {
	Center Point1
	Radius int
}

type Wheel1 struct {
	Circle Circle1
	Spokes int 
}

func playWithCirclesAnWheel1() {
	var c Circle1
	c.Center.X = 10
	c.Center.Y = 20
	c.Radius = 50
	fmt.Println("Cicle: ", c)

	// c.X = 100
	// c.Y = 200
	// c.Radius = 500
	// fmt.Println("Cicle: ", c)

	var w Wheel1
	w.Circle.Center.X = 10
	w.Circle.Center.Y = 20
	w.Circle.Radius = 50
	w.Spokes = 24
	fmt.Println("Wheel: ", w)
}

//_________________________________________________________________

type Point2 struct {
	X int
	Y int
}

// Compostion Design Pattern
// Structure Embedding
type Circle2 struct { 	// Embedding Structure
	Point2  			// Embedded Structure	
	Radius int
}

type Wheel2 struct {
	Circle2
	Spokes int 
}

func playWithCirclesAnWheel2() {
	var c Circle2
	c.Point2.X = 10
	c.Point2.Y = 20
	c.Radius = 50
	fmt.Println("Cicle: ", c)

	// Embedded Structure Members Can Be Accessed Directly
	//		By Instance Of Embedding Structure
	c.X = 100 
	c.Y = 200
	c.Radius = 500
	fmt.Println("Cicle: ", c)

	var w Wheel2
	w.Circle2.Point2.X = 10
	w.Circle2.Point2.Y = 20
	w.Circle2.Radius = 50
	w.Spokes = 24
	fmt.Println("Wheel: ", w)

	w.X = 11
	w.Y = 22
	w.Radius = 55
	w.Spokes = 25
	fmt.Println("Wheel: ", w)

	var ww Wheel2
	ww = Wheel2{ Circle2{ Point2{ 88, 99 }, 100 }, 24 }
	fmt.Println("Wheel : ", ww)

	var www Wheel2
	www = Wheel2 { // Labelled Initialser
			Circle2 : Circle2{ 
				Point2 : Point2{ 
					X: 88, 
					Y: 99, 
				}, 
				Radius: 100,
			}, 
			Spokes: 24 ,
		  }
	fmt.Println("Wheel : ", www)
}

//_________________________________________________________________

type SomePoint struct {
	X, Y int 
}

// Functions Taking Structure Object As Argument
func ScaleSomePoint( point SomePoint, factor int ) SomePoint {
	return SomePoint{ point.X * factor, point.Y * factor }
}

// Functions Taking Structure Object As Argument
func AddSomePoint( point1 SomePoint, point2 SomePoint ) SomePoint {
	return SomePoint{ point1.X + point2.X, point1.Y + point2.Y }
}

func playWithSomePointType() {
	point1 := SomePoint{ 10, 20 }
	point2 := SomePoint{ 100, 200 }
	point3 := SomePoint{ 10, 20 }

	fmt.Println("point1 : ", point1 )
	fmt.Println("point2 : ", point2 )
	fmt.Println("point3 : ", point3 )

	fmt.Println("point1 == point2 : ", point1 == point2 )
	fmt.Println("point1 == point3 : ", point1 == point3 )

	fmt.Println("point1 : ", ScaleSomePoint( point1, 10 ) )
	fmt.Println("point2 : ", ScaleSomePoint( point2, 5 ) )
	fmt.Println("point3 : ", ScaleSomePoint( point3, 2 ) )

	point4 := AddSomePoint( point1, point2 )
	fmt.Println("point4 : ", point4 )
}


//_________________________________________________________________

type Point struct {
	X, Y float64 
}

// Function Taking Two Arguments Of Point Type
func Distance( p Point, q Point ) float64 {
// func Distance( p, q Point ) float64 {
	fmt.Println("Function: Distance Called...")
	return math.Hypot( q.X - p.X, q.Y - p.Y )
}

// Method: Member Function
// In Go Language
//		Receiver Object Is Passed Explicity
//			Receiver Object Has Type Receiver Type
//		It's Member Of Point Type

// Here p Is Receiver Object Of Receiver Type Point
///	  Receiver Object Is Mentioned Outside Of Arguments
//			Followed By func KeyWord and Before Function Name
func ( p Point ) Distance( q Point ) float64 {
		fmt.Println("Point : Distance Member Method Called...")
		return math.Hypot( q.X - p.X, q.Y - p.Y )
}

// In C++/Java Language
//		this Is Keyword Reserved For Receiver Object
//		this Is Receiver Object And It's Implicitly Passed

// In Go Langauge
//		this Is Receiver Object And It's Explicitly Passed
//		 	We Can Name Receiver Object With Any Name
// func ( this Point ) Distance( q Point ) float64 {
// 		fmt.Println("Member Method: Distance Called...")
// 		return math.Hypot( q.X - this.X, q.Y - this.Y )
// }

// Go Doesn't Support Function Overloading

// Function Taking Two Arguments Of Point Type And float64 Type
func ScalePoint( point Point, factor float64 ) Point {
	fmt.Println("Function: ScalePoint Called...")
	return Point{ point.X * factor, point.Y * factor }
}

// Method i.e. Member Function On Point Type
//		Receiver Object point Of Point Type
// func (point Point) ScalePoint( factor float64 ) Point {
// 		fmt.Println("Member Method: ScalePoint Called...")
// 		return Point{ point.X * factor, point.Y * factor }
// }

// Reciever Object Is Passed By Value
// func (point Point) ScalePoint( factor float64 ) {
// 		fmt.Println("Member Method: ScalePoint Called...")
// 		point.X = point.X * factor
// 		point.Y = point.Y * factor
// }

// Reciever Object Is Passed By Reference
func (point * Point) ScalePoint( factor float64 ) {
		fmt.Println("Member Method: ScalePoint Called...")
		point.X = point.X * factor
		point.Y = point.Y * factor
}

func playWithPointType() {
	point1 := Point{ 10.0, 20.0 }
	point2 := Point{ 100.0, 200.0 }
	// point3 := Point{ 0.0, 0.0 }
	var distance float64

	// Function Call
	distance = Distance( point1, point2 ) 
	fmt.Println("Distance: ", distance )

	// Method Call
	// 		Here point1 Is Playing Role Of Receiver Object
	//		Hence p Will Be Assigned point1
	//		Hence q Will Be Assigned point2
	distance = point1.Distance( point2 ) 
	fmt.Println("Distance: ", distance )

	point3 := Point{ 11.0, 22.0 }
	fmt.Println("point3: ", ScalePoint( point3, 3.0 ) )

	// point3 Is Receiver Object
	// fmt.Println("point3: ", point3.ScalePoint( 3.0 ) )
	point3.ScalePoint( 3.0 )
	fmt.Println("point3: ", point3 )
}

//_________________________________________________________________

type Path []Point

func ( path Path ) Distance() float64 {
	fmt.Println("Path : Distance Member Method Called...")
	sum := 0.0
	for i := range path {
		if i > 0 {
			// Calculting AC = AB + BC
			sum += path[ i - 1 ].Distance( path[i] )
		}
	}
	return sum
}

func playWithPointAndPathType() {
	point1 := Point{ 10.0, 20.0 }
	point2 := Point{ 50.0, 60.0 }
	point3 := Point{ 100.0, 100.0 }
	var distance float64

	// Method Call
	// 		Here point1 Is Playing Role Of Receiver Object
	//		Hence p Will Be Assigned point1
	//		Hence q Will Be Assigned point2
	distance = point1.Distance( point2 ) 
	fmt.Println("Distance: ", distance )

	distance = point2.Distance( point3 ) 
	fmt.Println("Distance: ", distance )

	var path Path = Path {
			// A               B                    C
			Point{ 0.0, 0.0 }, Point{ 10.0, 10.0 }, Point{ 20.0, 20.0 },
		}

	// Method Call
	// 		Here path Is Playing Role Of Receiver Object
	distance = path.Distance() 
	fmt.Println("Distance: ", distance )
}

//_________________________________________________________________

type ColoredPoint struct { 	// Embedding Type
	Point 					// Embedded Type
	Color color.RGBA
}


func playWithColoredPointMethods() {
	var distance float64

	point1 := Point{ 10.0, 20.0 }
	point2 := Point{ 50.0, 60.0 }

	distance = point1.Distance( point2 ) 
	fmt.Println("Distance: ", distance )

	red 	:= color.RGBA{ 255, 0, 0, 255 }
	blue 	:= color.RGBA{ 0, 255, 0, 255 }

	var colouredPoint1 = ColoredPoint{ Point{ 10.0, 20.0 }, red }
	var colouredPoint2 = ColoredPoint{ Point{ 11.0, 22.0 }, blue }

	fmt.Println("X : ", colouredPoint1.X )
	fmt.Println("Y : ", colouredPoint1.Y )

	fmt.Println("X : ", colouredPoint2.X )
	fmt.Println("Y : ", colouredPoint2.Y )

	// distance = colouredPoint1.Distance( colouredPoint2 ) 
	// cannot use colouredPoint2 (variable of type ColoredPoint) as Point value 
	//		in argument to colouredPoint1.Distance

	distance = colouredPoint1.Distance( colouredPoint2.Point ) 
	fmt.Println("Distance: ", distance )
}

//___________________________________________________________________
//___________________________________________________________________

// HOME WORK
// HOME WORK
// HOME WORK

//___________________________________________________________________
//___________________________________________________________________

// An IntSet is a set of small non-negative integers.
// 		Its zero value represents the empty set.
type IntSet struct {
	words []uint64
}

// Has reports whether the set contains the non-negative value x.
func (s *IntSet) Has(x int) bool {
	word, bit := x/64, uint(x%64)
	return word < len(s.words) && s.words[word]&(1<<bit) != 0
}

// Add adds the non-negative value x to the set.
func (s *IntSet) Add(x int) {
	word, bit := x/64, uint(x%64)
	for word >= len(s.words) {
		s.words = append(s.words, 0)
	}
	s.words[word] |= 1 << bit
}

// UnionWith sets s to the union of s and t.
func (s *IntSet) UnionWith(t *IntSet) {
	for i, tword := range t.words {
		if i < len(s.words) {
			s.words[i] |= tword
		} else {
			s.words = append(s.words, tword)
		}
	}
}

// String returns the set as a string of the form "{1 2 3}".
func (s *IntSet) String() string {
	var buf bytes.Buffer
	buf.WriteByte('{')
	for i, word := range s.words {
		if word == 0 {
			continue
		}
		for j := 0; j < 64; j++ {
			if word&(1<<uint(j)) != 0 {
				if buf.Len() > len("{") {
					buf.WriteByte(' ')
				}
				fmt.Fprintf(&buf, "%d", 64*i+j)
			}
		}
	}
	buf.WriteByte('}')
	return buf.String()
}

//___________________________________________________________________

func playWithIntSet() {
	var x, y IntSet
	x.Add(1)
	x.Add(144)
	x.Add(9)
	fmt.Println(x.String()) // "{1 9 144}"

	y.Add(9)
	y.Add(42)
	fmt.Println(y.String()) // "{9 42}"

	x.UnionWith(&y)
	fmt.Println(x.String()) // "{1 9 42 144}"

	fmt.Println(x.Has(9), x.Has(123)) // "true false"

	// Output:
	// {1 9 144}
	// {9 42}
	// {1 9 42 144}
	// true false
}

//___________________________________________________________________

func playWithIntSetAgain() {
	var x IntSet
	x.Add(1)
	x.Add(144)
	x.Add(9)
	x.Add(42)

	fmt.Println( &x )         // "{1 9 42 144}"
	fmt.Println( x.String() ) // "{1 9 42 144}"
	fmt.Println(x)          // "{[4398046511618 0 65536]}"

	// Output:
	// {1 9 42 144}
	// {1 9 42 144}
	// {[4398046511618 0 65536]}
}

//_________________________________________________________________
//_________________________________________________________________
//_________________________________________________________________
//_________________________________________________________________

func main() {
	fmt.Println("\n\nFunction: playWithPerson")
	playWithPerson()

	fmt.Println("\n\nFunction: playWithTypes")
	playWithTypes()

	fmt.Println("\n\nFunction: playWithCirlcesAnWheel0")
	playWithCirlcesAnWheel0()

	fmt.Println("\n\nFunction: playWithCirclesAnWheel1")
	playWithCirclesAnWheel1()

	fmt.Println("\n\nFunction: playWithCirclesAnWheel2")
	playWithCirclesAnWheel2()

	fmt.Println("\n\nFunction: playWithSomePointType")
	playWithSomePointType()

	fmt.Println("\n\nFunction: playWithPointType")
	playWithPointType()

	fmt.Println("\n\nFunction: playWithPointAndPathType")
	playWithPointAndPathType()

	fmt.Println("\n\nFunction: playWithColoredPointMethods")
	playWithColoredPointMethods()

	fmt.Println("\n\nFunction : playWithIntSet")
	playWithIntSet()

	fmt.Println("\n\nFunction : playWithIntSetAgain")
	playWithIntSetAgain()

	// fmt.Println("\n\nFunction: ")
	// fmt.Println("\n\nFunction: ")
	// fmt.Println("\n\nFunction: ")	
	// fmt.Println("\n\nFunction: ")	
	// fmt.Println("\n\nFunction: ")
	// fmt.Println("\n\nFunction: ")
	// fmt.Println("\n\nFunction: ")	
}


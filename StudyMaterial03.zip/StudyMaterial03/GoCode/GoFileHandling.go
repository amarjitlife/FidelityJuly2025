
package main 

import (
	"fmt"
	"os"
	"bufio"
	"io"
)

//___________________________________________________________________

func check( err error ) {
	if err != nil {
		panic( err )
	}
}

//___________________________________________________________________


func playWithFileReading() {
	data, err := os.ReadFile("./dataFile1.txt")
	check( err )
	fmt.Print( string( data ) )

	f, err := os.Open("./dataFile2.txt")
	// f.Close()
	defer f.Close()

	check( err )

	buffer1 := make( []byte, 10 ) // chunks
	n1, err := f.Read( buffer1 )
	fmt.Printf(" %d Bytes: %s \n", n1, string( buffer1[ : n1 ]))
    o2, err := f.Seek(6, 0)
    check(err)

    b2 := make([]byte, 2)

    n2, err := f.Read(b2)
    check(err)
    fmt.Printf("%d bytes @ %d: ", n2, o2)
    fmt.Printf("%v\n", string(b2[:n2]))

    o3, err := f.Seek(6, 0)
    check(err)
    b3 := make([]byte, 2)
    
    n3, err := io.ReadAtLeast(f, b3, 2)
    check(err)
    fmt.Printf("%d bytes @ %d: %s\n", n3, o3, string(b3))

    _, err = f.Seek(0, 0)
    check(err)

    r4 := bufio.NewReader(f)

    b4, err := r4.Peek(5)
    check(err)
    fmt.Printf("5 bytes: %s\n", string(b4))

    // f.Close()
}

//___________________________________________________________________

func playWithFileWriting() {
    d1 := []byte("hello\ngo\n")

    err := os.WriteFile("./dataWritten1.txt", d1, 0644)
    check(err)

    f, err := os.Create("./dataWritten2.txt")
    check(err)
    defer f.Close()

    d2 := []byte{115, 111, 109, 101, 10}
    n2, err := f.Write(d2)
    check(err)
    fmt.Printf("wrote %d bytes\n", n2)

    n3, err := f.WriteString("writes\n")
    check(err)
    fmt.Printf("wrote %d bytes\n", n3)

    f.Sync()

    w := bufio.NewWriter(f)
    n4, err := w.WriteString("buffered\n")
    check(err)
    fmt.Printf("wrote %d bytes\n", n4)

    w.Flush()
}

//___________________________________________________________________
//___________________________________________________________________
//___________________________________________________________________
//___________________________________________________________________

func main() {
	fmt.Println("\n\nFunction: playWithFileReading")
	playWithFileReading()

	fmt.Println("\n\nFunction: playWithFileWriting")
	playWithFileWriting()

	// fmt.Println("\n\nFunction: ")
	// fmt.Println("\n\nFunction: ")
	// fmt.Println("\n\nFunction: ")
	// fmt.Println("\n\nFunction: ")
	// fmt.Println("\n\nFunction: ")
	// fmt.Println("\n\nFunction: ")
	// fmt.Println("\n\nFunction: ")
	// fmt.Println("\n\nFunction: ")	
}
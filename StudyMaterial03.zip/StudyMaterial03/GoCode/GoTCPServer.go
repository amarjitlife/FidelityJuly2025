
package main

import (
	"fmt"
	"time"
	"io"
	"log"
	"net"
)

//___________________________________________________________________

func handleConnection( connection net.Conn ) {
	for {
		_, err := io.WriteString( connection,
								  time.Now().Format( time.RFC850 ) + "\n" )
		if err != nil {
			log.Print("Client Disconnected!")
			return
		}
		fmt.Println("TCP Server: Handling Client Request!")
		time.Sleep( 3 * time.Second )
	}
}

func startTCPServer() {
	tcpListener, err := net.Listen( "tcp", "localhost:8000" )
	if err != nil {
		log.Fatal( err )
	}
	fmt.Println("TCP Server: Started!")

	for {
		connection, err := tcpListener.Accept()
		if err != nil {
			log.Fatal( err )
			continue
		}
		fmt.Println("TCP Server: Accepted Client Connection!")

		go handleConnection( connection )
	}
}

//___________________________________________________________________
//___________________________________________________________________
//___________________________________________________________________
//___________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!
//___________________________________________________________________

func main() {
	fmt.Println("\nFunction : startTCPServer")
	startTCPServer()

	// fmt.Println("\nFunction : ")	
	// fmt.Println("\nFunction : ")	
	// fmt.Println("\nFunction : ")	
	// fmt.Println("\nFunction : ")	
}


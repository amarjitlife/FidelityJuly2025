
package main

import (
	"fmt"
	// "time"
	"io"
	"log"
	"net"
	"os"
)

//___________________________________________________________________

func startTCPClient() {
	connection, err := net.Dial("tcp", "localhost:8000")
	if err != nil {
		log.Fatal( err )
	}
	fmt.Println("TCP Client: Connected!")
	mustCopy( os.Stdout, connection )
	// mustCopy( os.Stdout, "\n" )
	mustCopy( connection, os.Stdin )
}

func mustCopy( dst io.Writer, src io.Reader ) {
	if _, err := io.Copy( dst, src ) ; err != nil {
		log.Fatal( err )
	}
}

//___________________________________________________________________
//___________________________________________________________________
//___________________________________________________________________
//___________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!
//___________________________________________________________________

func main() {
	fmt.Println("\nFunction : startTCPClient")
	startTCPClient()

	// fmt.Println("\nFunction : ")	
	// fmt.Println("\nFunction : ")	
	// fmt.Println("\nFunction : ")	
}


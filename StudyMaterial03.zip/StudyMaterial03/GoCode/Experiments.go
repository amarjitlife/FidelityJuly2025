

package main
import "fmt"

//___________________________________________

type Circle struct {
	  radius float64
	  area float64
}

// c Is Receiver Object: Pass By Value
func (c Circle) calcArea() {
	  fmt.Println("Area Before Change: ", c.area )
	  c.area = 3.14 * c.radius * c.radius		
	  fmt.Println("Area After Change: ", c.area )
}

// {radius:5 area:0}
// {radius:5 area:0}

// c Is Receiver Object: Pass By Reference
// func (c *Circle) calcArea() {
// 	  c.area = 3.14 * c.radius * c.radius
// }

// {radius:5 area:0}
// {radius:5 area:78.5}

//___________________________________________
//___________________________________________
//___________________________________________
//___________________________________________
//___________________________________________

func main() {
	  c := Circle{ radius: 5 }
	  fmt.Printf("%+v\n", c)	  
	  c.calcArea()
	  fmt.Printf("%+v\n", c)
}


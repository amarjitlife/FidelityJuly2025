
package main

import (
	"fmt"
	"math"
)

//_________________________________________________________________


// DESIGN PRINCIPLE
//		Design Towards Interfaces/Abstract Types Rather Than Concrete Classes/Structure/State
//		Interfaces Defines Protocol Of Communication
//			It Forces Communication Contract Between Objects


type Spiderman struct { }
// Member Methods Of Type Spiderman
func ( s Spiderman ) Fly() 			{  fmt.Println("Fly Like Spiderman!" )  }
func ( s Spiderman ) SaveWorld() 	{  fmt.Println("SaveWorld Like Spiderman!" )  }

type Superman struct { }
// Member Methods Of Type Superman
func ( s Superman ) Fly() 			{  fmt.Println("Fly Like Superman!" )  }
func ( s Superman ) SaveWorld() 	{  fmt.Println("SaveWorld Like Superman!" )  }

type Wonderwoman struct { }
// Member Methods Of Type Wonderwoman
func ( s Wonderwoman ) Fly() 			{  fmt.Println("Fly Like Wonderwoman!" )  }
func ( s Wonderwoman ) SaveWorld() 		{  fmt.Println("SaveWorld Like Wonderwoman!" )  }

type Human struct { }
// Member Methods Of Type Human
func ( s Human ) Fly() 			{  fmt.Println("Fly Like Human!" )  }
func ( s Human ) SaveWorld() 	{  fmt.Println("SaveWorld Like Human!" )  }

//_________________________________________________________________

func playWithWorld() {
	var s Spiderman = Spiderman{}
	s.Fly()
	s.SaveWorld()

	var ss Superman = Superman{}
	ss.Fly()
	ss.SaveWorld()

	var ww Wonderwoman = Wonderwoman{}
	ww.Fly()
	ww.SaveWorld()

	var h Human = Human{}
	h.Fly()
	h.SaveWorld()
}

//_________________________________________________________________

// Interface Defines
//		What To Do!
//		i.e. Defines A Contract
type Superpower interface {
	Fly()
	SaveWorld() 
}

// Polymorphic Function
//		Using Mechanism Of Inteface Arguments
//		Interface Arguments Created A Contract 
func playWith( power Superpower ) {
	power.Fly()
	power.SaveWorld()
}

func playWithWorldAgain() {
	var s Spiderman = Spiderman{}
	playWith( s )

	var ss Superman = Superman{}
	playWith( ss )

	var ww Wonderwoman = Wonderwoman{}
	playWith( ww )

	var h Human = Human{}
	playWith( h )
}

func playWithWorldOnceAgain() {
	// Generic Array
	var powers = [...]Superpower{ Spiderman{}, Superman{}, Wonderwoman{}, Human{} }

	for _, power := range powers {
		playWith( power )
	}
}

//_________________________________________________________________
// Go Language Follows Duck Typing

// In computer programming, duck typing is an application of the duck test
// "If it walks like a duck and it quacks like a duck, then it must be a duck"

// Interface Defines
//		What To Do!
//		Interfaces Defines Abstract Types
type Geometry interface {
	area() float64
	perimeter() float64
}

// Structs Defines
//		Why, When, Which Way, Where, Decision Logic
//		Structs Defines Concrete Types
type Rectangle struct 	{ width, height float64 }
type Circle struct 		{ radius float64 }
type Square struct 		{ side float64 }

// area() Is Method On Receiver Object r Of Receiver Type Rectangle

func ( r Rectangle ) area() float64 		{ return r.width * r.height }
func ( r Rectangle ) perimeter() float64 	{ return 2 * (r.width + r.height) }

func ( c Circle ) area() float64 		{ return math.Pi * c.radius * c.radius }
func ( c Circle ) perimeter() float64 	{ return 2 * math.Pi * c.radius }
func ( c Circle ) origin() (float64, float64) 	{ return 0.0, 0.0 }

func ( s Square ) area() float64 		{ return s.side * s.side  }
func ( s Square ) perimeter() float64 	{ return 4 * s.side }

// Polymorphic Function
//		Using Argument Of Geometry Interface
func caculateGeometry( g Geometry ) {
	fmt.Println("Geometry 	: ", g )
	fmt.Println("Geometry Area 	: ", g.area() )
	fmt.Println("Geometry Perimeter : ", g.perimeter() )
}

func playWithGeometryObjects() {
	rectangle := Rectangle{ 10.0, 20.0 }
	caculateGeometry( rectangle )

	square := Square{ 22.0 }
	caculateGeometry( square )		

	circle := Circle{ 11.0 }
	caculateGeometry( circle )	

	cx, cy := circle.origin()
	fmt.Println("Circle Origin: ", cx, cy )
}

//___________________________________________________________________

// Writer is the interface that wraps the basic Write method.

type Writer interface {
		Write(p []byte) (n int, err error)
}

// Write writes len(p) bytes from p to the underlying data stream.
// It returns the number of bytes written from p (0 <= n <= len(p))
// and any error encountered that caused the write to stop early.
// Write must return a non-nil error if it returns n < len(p).
// Write must not modify the slice data, even temporarily.
//
// Implementations must not retain p.


// Reader is the interface that wraps the basic Read method.

type Reader interface {
		Read(p []byte) (n int, err error)
}

// Closer is the interface that wraps the basic Close method.

type Closer interface {
		Close() error
}

// The behavior of Close after the first call is undefined.
// Specific implementations may document their own behavior.

// Seeker is the interface that wraps the basic Seek method.
//
type Seeker interface {
		Seek(offset int64, whence int) (int64, error)
}

// Seek sets the offset for the next Read or Write to offset,
// interpreted according to whence:
// [SeekStart] means relative to the start of the file,
// [SeekCurrent] means relative to the current offset, and
// [SeekEnd] means relative to the end
// (for example, offset = -2 specifies the penultimate byte of the file).
// Seek returns the new offset relative to the start of the
// file or an error, if any.
//
// Seeking to an offset before the start of the file is an error.
// Seeking to any positive offset may be allowed, but if the new offset exceeds
// the size of the underlying object the behavior of subsequent I/O operations
// is implementation-dependent.


//_________________________________________________________________
//_________________________________________________________________
//_________________________________________________________________
//_________________________________________________________________

func main() {
	fmt.Println("\n\nFunction: playWithWorld")
	playWithWorld()

	fmt.Println("\n\nFunction: playWithWorldAgain")
	playWithWorldAgain()

	fmt.Println("\n\nFunction: playWithWorldOnceAgain")
	playWithWorldOnceAgain()

	fmt.Println("\n\nFunction: playWithGeometryObjects")
	playWithGeometryObjects()

	// fmt.Println("\n\nFunction: ")
	// fmt.Println("\n\nFunction: ")
	// fmt.Println("\n\nFunction: ")	
	// fmt.Println("\n\nFunction: ")
}

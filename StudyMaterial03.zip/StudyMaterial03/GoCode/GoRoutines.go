
package main

import (
	"fmt"
	"time"
	"sync"
	"sync/atomic"
)

//___________________________________________________________________

func doSomething( from string ) {
	for i := 0 ; i < 3 ; i++ {
		fmt.Println( from, " : ", i )
		time.Sleep( time.Second * 2 )
	}
}

func playWithGo() {
	fmt.Println( time.Now().Format( time.RFC850 ) )
	// Task 01
	doSomething("Oyee Hoyeee!")
	// Task 02
	doSomething("Welcome!")
	// Task 03
	// Anonymous Function : Closures
	func( message string ) {
		for i := 0 ; i < 4 ; i++ {
			fmt.Println( message, " : ", i )
			time.Sleep( time.Second * 2 )			
		}
		time.Sleep( time.Second * 3 )
	}("Hello!")

	// // Task 04
	// func() {
	// 	for {

	// 	}
	// }()
	time.Sleep( time.Second * 2 )
	fmt.Println( time.Now().Format( time.RFC850 ) )
	fmt.Println("Done: playWithGoRoutines")
}

//	Concurrency Is Idea Related Of System Modelling/Design
//		We Are Modelling System Using Code
//		Hence Concurrency Is Idea Related To Code Modelling/Design
//		Modelling Problem Solution Design As Concurrent

//	Parallelism Is Idea Related To Execution
//			e.g. Modelled In 04 Tasks

func playWithGoRoutines() {
	fmt.Println( time.Now().Format( time.RFC850 ) )

	// Task 01
	go doSomething("Oyee Hoyeee!")
	// Task 02
	go doSomething("Welcome!")
	// Task 03
	// Anonymous Function : Closures
	go func( message string ) {
		for i := 0 ; i < 4 ; i++ {
			fmt.Println( message, " : ", i )
			time.Sleep( time.Second * 2 )			
		}
		time.Sleep( time.Second * 3 )
	}("Hello!")

	// Task 04
	go func() {
		for {
		}
	}()

	time.Sleep( time.Second * 2 )
	fmt.Println( time.Now().Format( time.RFC850 ) )
	fmt.Println("Done: playWithGoRoutines")
}

// Function : playWithGoRoutines
// Tuesday, 22-Jul-25 10:15:55 IST
// Oyee Hoyeee!  :  0
// Oyee Hoyeee!  :  1
// Oyee Hoyeee!  :  2
// Welcome!  :  0
// Welcome!  :  1
// Welcome!  :  2
// Hello!  :  0
// Hello!  :  1
// Hello!  :  2
// Hello!  :  3
// Done: playWithGoRoutines

// Go Runtime Maintains
//		Go Thread Pool Of Size M 
//			On Which Go Routines Will Be Scheduled
// 		Go Runtime Will Schedule K Go Routines
//			On Subset Of M Go Threads
//			M Is Generally Far Less Than K

// Go Runtime Will Have Pool Of M Go Threads
//		M Go Threads Will Scheduled On N OS Threads

// Go Runtime Does M:N Scheduling
//		Green Threads (User Level Threads) : M
//		OS Threads : N

//___________________________________________________________________

// Cooperative Concurrency
//		By Default
//			Go Routines Runs Indepedent Of Each Other
// 		Go Routines Are Cooperative In Nature
//			Cooperation Is Achieved Through Message Passing + Payload/Data
//			Message Passing Requires Communication Mechanism
//				Channels
//___________________________________________________________________

func playWithChannels() {
	// Creating messages Channel Of Type chan
	//		To Communication Messages In string Type Data
	messages := make( chan string ) 

	// Writer | Producer
	go func() { // Go Routine Name: PingPong
		// Writing To messages Channel
		//		<- After Channel Means Writing
		time.Sleep( time.Second * 2 )
		messages <- "Ping"

		time.Sleep( time.Second * 2 )
		messages <- "Pong"

		time.Sleep( time.Second * 2 )
		messages <- "Ting"
	}()

	// Reader | Consumer
	// Reading To messages Channel
	//		<- Before Channel Means Reading
	messageRead := <- messages
	fmt.Println("Message: ", messageRead )

	messageRead = <- messages
	fmt.Println("Message: ", messageRead )

	messageRead = <- messages
	fmt.Println("Message: ", messageRead )

	// messageRead = <- messages
	// Fatal error: all goroutines are asleep - deadlock!
	// goroutine 1 [chan receive]:
	// main.playWithChannels()
	// 	/home/amarjit/Documents/Trainings.Running/Fidelity.GoLang/Progress/GoRoutines.go:149 +0x24a
	// fmt.Println("Message: ", messageRead )

	fmt.Println("Done: playWithChannels")
}

//___________________________________________________________________

func sum( numbers []int, messages chan int ) {
	sum := 0
	for _, number := range numbers {
		sum += number
	}
	messages <- sum
}

func playWithSum() {
	// messages Channel Used For Communication Data/Result
	messages := make( chan int )

	// Large Problem To Solve
	//		e.g. You Have Huge Numbers List
	//		Data Item Itself Is Indepent
	numbers := []int { 1, 2, 9, -9, 4, 0, 7, 10 }

	// Mapping Large Problem To Smaller Problems
	//		e.g. Divining Huge Numbers List
	//				Into Smaller Numbers List
	//				Adding Each Smaller List Seperately
	go sum( numbers[ : len( numbers ) / 2 ], messages )
	go sum( numbers[ len( numbers ) / 2 : ], messages )

	// Collecting Sum Of Smaller List
	sum1 := <- messages
	sum2 := <- messages
	// Calculating Complete Sum
	total := sum1 + sum2
	fmt.Println("Total : ", total)
}

//___________________________________________________________________

// Global Variable Is Bad Coding Practice
var workStatus bool

func worker1( ) {
	fmt.Println("Worker: Started...")
	time.Sleep( time.Second * 3 ) // Worker Doing Some Heavy Work
	fmt.Println("Worker: Work Done!")
	workStatus = true
}

func playWithWorkers1() {
	workStatus = false
	fmt.Println("Work Status: ", workStatus )
	worker1()
	fmt.Println("Work Status: ", workStatus )
}

// Better Design
func worker2() bool {
	fmt.Println("Worker: Started...")
	time.Sleep( time.Second * 3 ) // Worker Doing Some Heavy Work
	fmt.Println("Worker: Work Done!")
	return true
}

func playWithWorkers2() {
	workStatus = false
	fmt.Println("Work Status: ", workStatus )
	workStatus = worker2()
	fmt.Println("Work Status: ", workStatus )
}

//___________________________________________________________________

// One suggestion (made by Rob Pike) for concurrent programming 
// is don't (let computations) communicate by sharing memory,

// (let them) share memory by communicating (through channels). 
// (We can view each computation as a goroutine in Go programming.)

// Status Communication Design
func worker( done chan bool ) {
	fmt.Println("Worker: Started...")
	time.Sleep( time.Second * 3 ) // Worker Doing Some Heavy Work
	fmt.Println("Worker: Work Done!")
	
	done <- true
}

func playWithWorkers() {
	done := make( chan bool )
	// done := make( chan bool, 1 )
	go worker( done )
	
	workStatus := <- done
	fmt.Println("Work Status: ", workStatus )
}

//___________________________________________________________________

func playWithClosingChannel() {
	// Buffered Channel : Channel Having Size
	//		e.g. Following Can Maintain Queue Of 2 Elements
	//		Writing Go Routine Can Write To It Channel Have Space
	//			Moment Channel Is Full Writing Go Routine Will Block
	//		Reading Go Routine Can Read From Channel Till It Have Data
	//			Moment Channel Is Empty Reading Go Routine Will Block
	messages := make ( chan string, 2 )

	messages <- "Hello!"
	messages <- "Hi!"
	// messages <- "Ola!"
	// Function : playWithClosingChannel
	// fatal error: all goroutines are asleep - deadlock!

	// goroutine 1 [chan send]:
	// main.playWithClosingChannel(...)
	// 	/home/amarjit/Documents/Trainings.Running/Fidelity.GoLang/Progress/GoRoutines.go:264

	fmt.Println("Data: ", <- messages )	
	fmt.Println("Data: ", <- messages )
	// fmt.Println("Data: ", <- messages )
	// fatal error: all goroutines are asleep - deadlock!

	// goroutine 1 [chan receive]:
	// main.playWithClosingChannel()
	// 	/home/amarjit/Documents/Trainings.Running/Fidelity.GoLang/Progress/GoRoutines.go:274 +0x185
	messages <- "Ola!"
	messages <- "Olaaaa!"
	close( messages )

	// messages <- "Olaaaaaaa!"	
	// panic: send on closed channel

	// fmt.Println("Data: ", <- messages )	
	// fmt.Println("Data: ", <- messages )	
	// Reading From Channel Using For Loop
	for message := range messages {
		fmt.Println( message )
	}
}

//___________________________________________________________________

// Producer
// Generator : Finite/Infinite Sequence Of Fibonancci Number
//		How Much Production To Be Done?
//		When Production To Be Stopped?
//		Both Above Decision Done By Producer
func fibonacci( count int, fibos chan int ) {
	x, y := 0, 1
	for i := 0 ; i < count ; i++ {
	// for i := 0 ; i < 10 ; i++ {
	// for i := 0 ;  ; i++ {
		fibos <- x
		x, y = y, x + y
	}
	// Completed Work 
	close( fibos )
}

func playWithFibonaccis() {
	// fibos := make( chan int )
	fibos := make( chan int, 10 )

	go fibonacci( cap( fibos ), fibos )

	// Keep Looping Till Receiver Close Message
	for fibo := range fibos { 
		fmt.Println( fibo )
	}

	// This range iterates over each element as it’s received from fibos Channel. 
	// Because we closed the channel in fibonacci Go Routine, 
	//	the iteration terminates after receiving Closing Status
}

//___________________________________________________________________

// Producer
// Generator : Infinite Sequence Of Fibonancci Number
func fibonacciAgain( fibos chan int, done chan bool ) {
	x, y := 0, 1
	for {
		select {
			case fibos <- x:
				x, y = y, x + y
			case shouldStop := <- done:
				if shouldStop == true {
					fmt.Println("Done! Command Receieved")
					return
				}
		}
	}
}

func playWithFibonaccisAgain() {
	fibos := make( chan int, 10 ) 	// Sending Fibonacci Numbers
	done := make( chan bool ) 		// Sending Commands
	readFibos := 10

	// Consumer
	//		How Much Production To Be Done?
	//		When Production To Be Stopped?
	//		Both Above Decision Done By Consumer
	go func() {
		for i := 0 ; i < readFibos ; i++ {
			fmt.Println("Fibo: ", <- fibos )
		}
		done <- true
	}()

	go fibonacciAgain( fibos, done )
	time.Sleep( 10 * time.Second )
}

//___________________________________________________________________

func playWithSelect() {
	tick := time.Tick( 100 * time.Millisecond )
	boom := time.Tick( 500 * time.Millisecond )

	for {
		select {
			case <- tick:
				fmt.Println("Tick")
			case <- boom:
				fmt.Println("Boom!")
				return
			default:
				fmt.Println("	.")
				time.Sleep( 50 * time.Millisecond )
		}
	}
}

// Go’s select lets you wait on multiple channel operations. 
// Combining goroutines and channels with select is a powerful feature of Go.

//___________________________________________________________________

func playWithSelectAgain() {
	messages := make( chan string, 1 )

	go func() {
		fmt.Println("Go Routine 01: Started...")
		time.Sleep( 2 * time.Second )
		// messages <- "GoRoutine 01 : Hi!"
		fmt.Println("Go Routine 01: Ended...")
	}()

	go func() {
		fmt.Println("Go Routine 02: Started...")
		select { // Blocking
			case result := <- messages:
				fmt.Println("Result: ", result)
		}

		fmt.Println("Go Routine 02: Ended...")
	}()

	go func() {
		fmt.Println("Go Routine 03: Started...")
		select { // Non-Blocking
			case result := <- messages:
				fmt.Println("Result: ", result)
			case <- time.After( 10 * time.Second ):
				fmt.Println("Timeout!")				
		}
		fmt.Println("Go Routine 03: Ended...")
	}()

	go func() {
		fmt.Println("Go Routine 04: Started...")
		select { // Non-Blocking
			case result := <- messages:
				fmt.Println("Result: ", result)
			default:
				fmt.Println("Quitting... I Can't Wait!")
		}
		fmt.Println("Go Routine 04: Ended...")
	}()

	time.Sleep( 60 * time.Second )	
	fmt.Println("playWithSelectAgain: Done!!!")
}

// Go’s select lets you wait on multiple channel operations. 
//	Combining goroutines and channels with select is a 
//	powerful feature of Go.

// Basic sends and receives on channels are blocking. 
//		However, we can use select with a default clause to 
//		implement non-blocking sends, receives, and even 
//		non-blocking multi-way selects.

// Non-blocking receive. If a value is available on 
//		messages then select will take the <-messages case 
//		with that value. 
//		If not it will immediately take the default case.

// 	We can use multiple cases above the default clause to 
//	implement a multi-way non-blocking select.

// Timeouts are important for programs that connect to 
//	external resources or that otherwise need to bound 
//	execution time. Implementing timeouts in Go is easy and 
//	elegant thanks to channels and select.

// Here’s the select implementing a timeout. 
//	result := <- messages awaits the result and 
//	<-time.After awaits a value to be sent after the timeout of 10 seconds. 
//	Since select proceeds with the first receive that’s ready, 
//	we’ll take the timeout case if the operation takes more 
//  than the allowed 1s.

//___________________________________________________________________

func playWithCancel() {
	jobs := make( chan int, 5 ) // For Sending Messages
	done := make( chan bool ) 	// For Sending Commands

	// Consumer
	go func() {
		for {
			job, status := <- jobs
			fmt.Println("Receiver Got: ", job, status )

			if status {
				fmt.Println("Received Job: ", job )
			} else {
				fmt.Println("Received All Jobs")				
				done <- true  // Consumer Informing Producer That I Am Done!
				return
			}
		}
	}()

	// Producer Producing
	for job := 1 ; job <= 3 ; job++ {
		jobs <- job // Writing To Channel jobs
		fmt.Println("Sent Job: ", job )
	}
	close( jobs ) // Producer Informing Consumer That I Am Done!
	fmt.Println("Sent All Jobs")				

	consumerStatus := <- done
	fmt.Println("Consumer Done: ", consumerStatus )

	// _, status := <- jobs // Here _ Means Ignore First Part Of Value Returned
	job, status := <- jobs
	fmt.Println("Reading Closed Channel: ", job, status )		
}

// Closing a channel indicates that no more values will be sent on it. 
//	This can be useful to communicate completion to the channel’s receivers.

// Here’s the Consumer goroutine. 
// It repeatedly receives from jobs with job, status := <- jobs. 
// In this special 2-value form of receive, the status value will be false 
// 		if jobs channel has been closed and 
//		all values in the channel have already been received. 
// We use this to notify on done when we’ve worked all our jobs.

// Reading from a closed channel succeeds immediately, 
//		returning the zero value of the underlying type. 
//		The optional second return value is true if the value 
//		received was delivered by a successful send operation to 
//		the channel, or false if it was a zero value generated because 
//		the channel is closed and empty.

//___________________________________________________________________

func playWithTimer() {
	fmt.Println( time.Now().Format( time.RFC850 ) )	
	timer1 := time.NewTimer( 10 * time.Second )
	fmt.Println("Timer 1 Created!")

	result := <- timer1.C
	fmt.Println("Timer 1 Fired: ", result )
	fmt.Println( time.Now().Format( time.RFC850 ) )

	timer2 := time.NewTimer( 4 * time.Second )
	fmt.Println("Timer 2 Created!")

	go func() {
		fmt.Println("Go Routine Started...")
		resultAgain := <- timer2.C
		fmt.Println("Timer 2 Fired: ", resultAgain )		
		fmt.Println("Go Routine Ended...")
	}()

	timerStopped := timer2.Stop()
	if timerStopped {
		fmt.Println("Timer 2 Stopped!")
	}

	time.Sleep( 10 * time.Second )
}

// We often want to execute Go code at some point in the future, or 
//	repeatedly at some interval. Go’s built-in timer and ticker '
//	features make both of these tasks easy. We’ll look first at 
//	timers and then at tickers.

// Timers represent a single event in the future. 
//	You tell the timer how long you want to wait, and 
//	it provides a channel that will be notified at that time. 

// If you just wanted to wait, you could have used time.Sleep. 
//	One reason a timer may be useful is that you can cancel 
//	the timer before it fires.

//___________________________________________________________________

func playWithTicker() {
	// Will Create Repeated Events
	// 		e.g. Following ticker Will Generate Event Every 1 Second
	ticker := time.NewTicker( 1000 * time.Millisecond )
	done := make( chan bool )

	go func() {
		for {
			select {
			case status := <- done:
				fmt.Println("Sent Command Done: ", status )
				return
			case tick := <- ticker.C:
				// Check With WhatsAppS Server
				//		New Message Arrived
				// go checkNetworkConnection( network )
				// status <- network
				// if status {
				// 		go checkWhatsAppServer()
				// }
				fmt.Println("Ticked At:", tick )
			}
		}
	}()

	time.Sleep( 5000 * time.Millisecond )
	ticker.Stop() // ticker that ticks periodically until we stop it.
	fmt.Println("Ticker Stopped!")
	done <- true
	fmt.Println("Sent Command Done!")
}

// Timers are for when you want to do something once in the future - 
//		tickers are for when you want to do something repeatedly 
//		at regular intervals. 

// Tickers use a similar mechanism to timers: 
//		a channel that is sent values. 
//	Here we’ll use the select builtin on the channel to 
//	await the values as they arriv

// Tickers can be stopped like timers. Once a ticker is stopped 
//	it won’t receive any more values on its channel.

//___________________________________________________________________
// Read Only Channel and Write Only Channel

// pings Is Write Only Channel
func doPing( pings chan<- string, data string ) {
	pings <- data
}

// pings Is Read Only Channel
// pongs Is Write Only Channel
func doPong( pings <-chan string, pongs chan<- string ) {
	data := <- pings
	pongs <- data
	// readFrom := <- pongs
	// invalid operation: cannot receive from send-only channel pings 
	//	(variable of type chan<- string)

	// pings <- "Trying To Write To Read Only Channel "
	// invalid operation: cannot send to receive-only channel pings 
	//	(variable of type <-chan string)
}

func playWithCannelWithReadWriteOnly() {
	pings := make( chan string, 1 )
	pongs := make( chan string, 1 )

	doPing( pings, "Hello!!!" )
	doPong( pings , pongs )

	fmt.Println("Message: ", <- pongs )
}

//___________________________________________________________________

func someWorker( id int, jobs <- chan int, results chan<- int ) {
	fmt.Println("Worker: Started", id)
	time.Sleep( 1 * time.Second )
	fmt.Println("Worker Completed", id )
	results <- ( <-jobs ) * 2

}

func playWithWorkersPool() {
	var jobNumbers = 15
	jobs 	:= make( chan int, jobNumbers )
	results := make( chan int, jobNumbers )
	// Worker Pool
	//		Launching Multiple Workers
	for w := 1 ; w <= 6 ; w++ {
		go someWorker(w, jobs, results)
	}

	for job := 11 ; job < jobNumbers ; job++ {
		jobs <- job
	}
	close( jobs )

	time.Sleep( 2 * time.Second )

	for job := 11 ; job <= jobNumbers ; job++ {
		jobStatus := <- results
		fmt.Println("Job Status: ", jobStatus)
	}
}

//___________________________________________________________________

func betterWorker( id int ) {
	// fmt.Println("Worker: Started", id)
	fmt.Printf(".")
	time.Sleep( 3 * time.Second )
	fmt.Printf("_")
	// fmt.Println("Worker Completed", id )
}

func playWithWaitGroup() {
	fmt.Println( time.Now().Format( time.RFC850 ) )

	var workersCount = 100000
	var wg sync.WaitGroup
	// WaitGroup Maintains A Counter
	//		wg.Add( 1 ) // Increasing Counter By 1
	//		wg.Done() 	// Decrease Counter By 1	
	// wg.Add( workersCount )
	for w := 1 ; w <= workersCount ; w++ {
		wg.Add( 1 )
		go func() {
			betterWorker( w )
			wg.Done() // Go Routine Marking I Am Done!
		}()
	}

	// time.Sleep( 10 * time.Second )
	fmt.Println("Main Waiting Started!!!")
	wg.Wait() // Introduced Wait Till Counter Become 0
	fmt.Println("Main Waiting Done!!!")

	// time.Sleep( 5 * time.Second )

	fmt.Println("playWithWaitGroup Done!!!")
	fmt.Println( time.Now().Format( time.RFC850 ) )
}

//___________________________________________________________________


func anotherWorker( id int ) {
	// fmt.Println("Worker: Started", id)
	fmt.Printf(".")
	time.Sleep( 3 * time.Second )
	fmt.Printf("_")
	// fmt.Println("Worker Completed", id )
}

func playWithGoRoutineCounting() {
	fmt.Println( time.Now().Format( time.RFC850 ) )
	var workersCount = 100000
	// var goRoutinesLauched = 0
	
	var goRoutinesLauched atomic.Uint64

	for w := 1 ; w <= workersCount ; w++ {
		// wg.Add( 1 )
		// goRoutinesLauched += 1 // Non Atomic
		goRoutinesLauched.Add( 1 )
		go func() {
			anotherWorker( w )
			// wg.Done() // Go Routine Marking I Am Done!
			// goRoutinesLauched -= 1 // Non Atomic
			// goRoutinesLauched.Add( -1 )
			// atomic.AddUint64( &goRoutinesLauched, ^uint64(0))
			// goRoutinesLauched := atomic.AddInt64( &goRoutinesLauched, -1)
		}()
	}

	fmt.Println("Main Waiting Started!!!")
	fmt.Println("Main Waiting Done!!!")

	time.Sleep( 20 * time.Second )
	fmt.Println( goRoutinesLauched ) 

	fmt.Println("playWithWaitGroup Done!!!")
	fmt.Println( time.Now().Format( time.RFC850 ) )
}

//___________________________________________________________________

// What Is Mutex?
//		Mutually Execlusive

type Counter struct {
	mu 			sync.Mutex
	counters 	map[string]int
}

func ( c* Counter ) increment( name string ) {
	c.mu.Lock()
	//	Crictical Section
	// c.counters Is Shared Resource Between Multiple Go Routines
	//		All These Go Routines Are Writing To Shared Resource
	//		Writing Should Be Atomic In Nature
	//			We Will Make It Crictical Section
	//			Hence Crictical Section Must Accessed Using Locking
	//			Using Mutex For Locking
	c.counters[name]++
	c.mu.Unlock()
}

func playWithCounterIncrement() {
	var wg sync.WaitGroup

	c := Counter { 
		counters: map[string]int { "A": 11, "B": 22, "C": 33 },
	}

	doIncrement := func ( name string, n int ) {
		for range n {
			c.increment( name )
		}
		wg.Done()
	}

	wg.Add( 3 )
	go doIncrement( "A", 10000 ) // Child Go Routine
	go doIncrement( "B", 10000 ) // Child Go Routine
	go doIncrement( "C", 10000 ) // Child Go Routine

	wg.Wait() // Making Parent Routine To Wait For Child Go Routines To Complete
	fmt.Println("Counter : ",  c.counters)
}

// we saw how to manage simple counter state using atomic operations. 
// For more complex state we can use a mutex to safely access data 
//	across multiple goroutines.

//___________________________________________________________________
//___________________________________________________________________
//___________________________________________________________________
//___________________________________________________________________
//___________________________________________________________________
//___________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

func main() {
	// fmt.Println("\nFunction : playWithGo")
	// playWithGo()

	// fmt.Println("\nFunction : playWithGoRoutines")
	// playWithGoRoutines()

	// fmt.Println("\nFunction : playWithChannels")
	// playWithChannels()

	// fmt.Println("\nFunction : playWithSum")
	// playWithSum()

	// fmt.Println("\nFunction : playWithWorkers1")	
	// playWithWorkers1()

	// fmt.Println("\nFunction : playWithWorkers2")	
	// playWithWorkers2()

	// fmt.Println("\nFunction : playWithWorkers")
	// playWithWorkers()

	// fmt.Println("\nFunction : playWithClosingChannel")
	// playWithClosingChannel()

	// fmt.Println("\nFunction : playWithFibonaccis")
	// playWithFibonaccis()	

	// fmt.Println("\nFunction : playWithFibonaccisAgain")
	// playWithFibonaccisAgain()

	// fmt.Println("\nFunction : playWithSelect")
	// playWithSelect()

	// fmt.Println("\nFunction : playWithSelectAgain")
	// playWithSelectAgain()

	// fmt.Println("\nFunction : playWithCancel")	
	// playWithCancel()

	// fmt.Println("\nFunction : playWithTimer")
	// playWithTimer()

	// fmt.Println("\nFunction : playWithTicker")	
	// playWithTicker()

	// fmt.Println("\nFunction : playWithCannelWithReadWriteOnly")
	// playWithCannelWithReadWriteOnly()	
	
	// fmt.Println("\nFunction : playWithWorkersPool")
	// playWithWorkersPool()

	// fmt.Println("\nFunction : playWithWaitGroup")	
	// playWithWaitGroup()

	// fmt.Println("\nFunction : playWithGoRoutineCounting")	
	// playWithGoRoutineCounting()

	fmt.Println("\nFunction : playWithCounterIncrement")
	playWithCounterIncrement()

	// fmt.Println("\nFunction : ")	
	// fmt.Println("\nFunction : ")	
	// fmt.Println("\nFunction : ")	
}


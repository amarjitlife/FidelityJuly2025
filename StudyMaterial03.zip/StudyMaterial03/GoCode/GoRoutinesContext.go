
package main

import (
	"fmt"
	"time"
	"context"
)

//___________________________________________________________________

func playWithContextWithCancel() {
	someContext, cancelContext := context.WithCancel( context.Background() )

	go func() {
		select {
			case <- time.After( 5 * time.Second ):
				fmt.Println("Receieved : Timeout!")
			case <- someContext.Done():
				fmt.Println("Received : Context Done!")
		}
	}()

	time.Sleep( 2 * time.Second )
	cancelContext()
	time.Sleep( 2 * time.Second )	
	fmt.Println("playWithContextWithCancel Done!")
}

//___________________________________________________________________

func playWithContextWithTimeout() {
	someContext, timeoutContext := context.WithTimeout( context.Background(), 
														5 * time.Second )

	go func() {
		select {
			case <- time.After( 8 * time.Second ):
				fmt.Println("Receieved : Timeout!")
			case <- someContext.Done():
				fmt.Println("Received : Context Done!")
		}
	}()

	timeoutContext()
	time.Sleep( 10 * time.Second )	
	fmt.Println("playWithContextWithTimeout Done!")
}

//___________________________________________________________________

func playWithContextWithDeadline() {
	deadline := time.Now().Add( 5 * time.Second )
	someContext, deadlineContext := context.WithDeadline( context.Background(), 
														 deadline )
	go func() {
		select {
			case <- time.After( 8 * time.Second ):
				fmt.Println("Receieved : Timeout!")
			case <- someContext.Done():
				fmt.Println("Received : Context Done!")
		}
	}()

	deadlineContext()
	time.Sleep( 10 * time.Second )	
	fmt.Println("playWithContextWithDeadline Done!")
}

//___________________________________________________________________

func playWithContextWithValues() {
	valuesContext := context.WithValue( context.Background(), 
														 "name", "Gabbar Singh" )
	go func( ctx context.Context ) {
		// select {
		// 	case <- time.After( 8 * time.Second ):
		// 		fmt.Println("Receieved : Timeout!")
		// 	case <- ctx.Done():
		// 		fmt.Println("Received : Context Done!")
		// }

		if v := ctx.Value( "name" ) ; v != nil {
			fmt.Println("Received Value: ", v )
		} else {
			fmt.Println("Received None!")
		}
	}( valuesContext )

	time.Sleep( 10 * time.Second )	
	fmt.Println("playWithContextWithValues Done!")
}

//___________________________________________________________________
//___________________________________________________________________
//___________________________________________________________________
//___________________________________________________________________
//___________________________________________________________________

// Contexts in Go provide a standard way to pass metadata and 
//		control signals between goroutines. 

// They are mainly used to manage 
//		task execution time, 
//		data passing, and operation cancellation.

// Introduction to Contexts
// 		Contexts in Go are represented by the context.Context interface, 
//		which includes methods for getting
//		deadlines, cancellation, values, and done channels

// Context Types
// There are six functions to create contexts:
// 1. context.Background() : 
//		Returns an empty context; It is usually used as the root context for the entire
// 		application.

// 2. context.TODO() : 
//		Returns a context that can be used when a context is required 
//		but not yet defined; It signals that the context needs further work.

// 3. context.WithCancel(parent Context) : 
//		Returns a derived context that can be canceled by calling the
// 		cancel function

// 4. context.WithDeadline(parent Context, d time.Time) : 
//		Returns a derived context that automatically
// 		cancels at a specified time (deadline)

// 5. context.WithTimeout(parent Context, timeout time.Duration) : 
//		Similar to the WithDeadline , but
// 		the deadline is set by a duration

// 6. context.WithValue(parent Context, key, val interface{}) : 
//		Returns a derived context that contains
// 		a key-value pair

// Contexts in Go are a powerful tool for managing execution time, cancelation, and 
// data passing between goroutines. Using contexts correctly helps avoid resource leaks, 
// ensures timely task completion, and improves code structure and readability. 
// Various types of contexts, such as those with cancellation, timeout, deadline,
// and values, provide flexible task management in Go applications.

//___________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!
//___________________________________________________________________

func main() {
	// fmt.Println("\nFunction : playWithContextWithCancel")
	// playWithContextWithCancel()

	// fmt.Println("\nFunction : playWithContextWithTimeout")	
	// playWithContextWithTimeout()

	// fmt.Println("\nFunction : playWithContextWithDeadline")
	// playWithContextWithDeadline()

	fmt.Println("\nFunction : playWithContextWithValues")
	playWithContextWithValues()

	// fmt.Println("\nFunction : ")	
	// fmt.Println("\nFunction : ")	
	// fmt.Println("\nFunction : ")	
	// fmt.Println("\nFunction : ")	
	// fmt.Println("\nFunction : ")	
}


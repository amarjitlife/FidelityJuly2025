
package main

import "fmt"

func main() {
	fmt.Println("Hello World! Welcome Fidelity Team!!!")
}

/* 
1. Running Go Program Directly
	go run Hello.go

2. Building and Running Go Program
	go build Hello.go
	./Hello
*/
